﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DAL;

/// <summary>
/// Descripción breve de Producto
/// </summary>
public class Producto
{
    public Producto()
    {
        //
        // TODO: Agregar aquí la lógica del constructor
        //
    }
}
public class Productos

{
    public long IDProducto { get; get; }
    public string Nombre { get; get; }
    public string Costo { get; get; }
    public string IDUsuario { get; get; }
    public string IDCategoria { get; get; }
    public string IDVentas { get; get; }
    public string IDAdministrador { get; get; }

    public long IDUsuario { get; get; }
    public string Contrasena { get; get;}
    public string Correo { get; get; }
    public string CP { get; get; }
    public string Administrador { get; get; }
    
    public long IDCategoria { get; get; }
    public string Categoria { get; get; }

    public long IDVentas { get; get; }
    public string Cantidad { get; get; }
    public string Descipcion { get; get; }

    public long IDAdministrador { get; get; }
    public string Usuario { get; get; }
    public string Contrasena { get; get; }



}